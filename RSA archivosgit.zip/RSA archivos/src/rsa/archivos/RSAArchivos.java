/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/*
15601988298452157133327341046226504916

a b c d e f g h i j k l m n ñ o p q r s t u v w x y z
*/

package rsa.archivos;


import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.math.BigInteger;
import java.security.SecureRandom;
import java.util.Arrays;
import java.util.Random;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;
/**
 *
 * @author pedro
 */
public class RSAArchivos {
    /**
     * @param args the command line arguments
     */
    
    
   private final static BigInteger one      = new BigInteger("1");
   private final static SecureRandom random = new SecureRandom();
    
   public static void main(String[] args) {
       /*BigInteger e= new BigInteger("9999831901");
       BigInteger n= new BigInteger("18479218829917294776751737162645225676863907650771350696042898978929");
       BigInteger d= new BigInteger("1512178782129346503670511664809619550062395368786285711752296698873");
       */
       BigInteger e= new BigInteger("21943");
       BigInteger n= new BigInteger("166968277225884209304483228221920453189");
       BigInteger d= new BigInteger("55021993921540751824901080195019440147");
       
         
           int caso=0;
           String respuesta="";
           for(int i=0;i<1;i++){
           respuesta = JOptionPane.showInputDialog("1. Generar Claves\n2. Cifrar\n3. Descifrar\n4. Salir");
           caso= Integer.parseInt(respuesta);
           if(caso<1||caso>4){
           i--;
           }
           }
           
           switch(caso){
           case 1:
           String bits = JOptionPane.showInputDialog("Escribe el numero de bits");
           generarclaves(Integer.parseInt(bits));
           break;
           
           case 2:
               dragdrop p=new dragdrop();
               p.setSize(444, 500);
               p.setResizable(false);
               p.setLocationRelativeTo(null);
               p.setVisible(true);
               
           break;
           
           case 3:
               dragdropdesenc q=new dragdropdesenc();
               q.setSize(444, 500);
               q.setResizable(false);
               q.setLocationRelativeTo(null);
               q.setVisible(true);
           break;
           
           case 4:
           System.exit(0);
           }
           
           
       
       
    }   
       
   
   
   
   
    public static void generarclaves(int bits){
      BigInteger p = BigInteger.probablePrime(bits/2, random);
      BigInteger q = BigInteger.probablePrime(bits/2, random);
      BigInteger phi = (p.subtract(one)).multiply(q.subtract(one));
      BigInteger n = p.multiply(q);   
      Random aleatorio = new Random(System.currentTimeMillis());
      int numeroaleatorio = aleatorio.nextInt(65537)+1;
      
      BigInteger e=new BigInteger(""+numeroaleatorio).nextProbablePrime();
      
      BigInteger d=e.modInverse(phi);
      
     // System.out.println("p: "+p);
     // System.out.println("q: "+q);
     //System.out.println("phi: "+phi);
      System.out.println("e: "+e);
      System.out.println("d: "+d);
      System.out.println("n: "+n);
    }
    
    
    
    public static void cifrar(String[] mensaje, BigInteger e, BigInteger n, PrintWriter wr){
	BigInteger cadenadenum;
        
        for (int k=0;k<mensaje.length;k++){
            char [] valor= mensaje[k].toCharArray();        
            
            for (int i = 0; i < valor.length; i++) {
                int valorascii = (int) valor[i];
                String valores=String.valueOf(valorascii);
                    if (valores.length()==2) {
                        valores="0"+valores;
                    } 
                cadenadenum= new BigInteger(valores);
                cadenadenum = cadenadenum.modPow(e,n);
                System.out.println(cadenadenum);
                wr.print(cadenadenum+"/");
            }
            wr.print(" ");
        }
     
    }

    

    
    
    public static void descifrar(String[] mensajecod, BigInteger d, BigInteger n,PrintWriter wr){	
        for(int p=0;p<mensajecod.length;p++){
            System.out.println("palabra a evaluar: "+mensajecod[p]);
            String mensaje = "";
            BigInteger mensajeBI = new BigInteger(mensajecod[p]);
            mensajeBI = mensajeBI.modPow(d, n);
            mensaje = String.valueOf(mensajeBI);
            String concatenar="";
            char caracter;
            int k=mensaje.length();
            int h=k%3;
            if (h!=0) {
                for (int i = 0; i < (3-h); i++) {
                    mensaje="0"+mensaje;   
                }   
            }
            for (int i = 0; i < mensaje.length(); i+=3) {

                String val=mensaje.substring(i, i+3);
                int numero=Integer.parseInt(val);

                  caracter = (char)numero;
                  concatenar+=caracter;
            }
            System.out.println(concatenar);
            wr.print(concatenar);
        }
        wr.print(" ");
    }
    
    
    
    
    public static void leerarchivocif(String archivo, BigInteger e,BigInteger n) throws FileNotFoundException, IOException{
        String cadena;
        int i=0;
        String ruta="";
        
        for(int l=0;l<archivo.length();l++){
            if(archivo.charAt(l)!='.'){
                ruta= ruta+archivo.charAt(l);
            }else{
                break;
            }
        }
        
        
        File k= new File(ruta+" cifrado.txt");
        FileWriter w = new FileWriter(k);
        BufferedWriter bw = new BufferedWriter(w);
        PrintWriter wr = new PrintWriter(bw);
        
        FileReader f = new FileReader(archivo);
        BufferedReader b = new BufferedReader(f);
        
        while((cadena = b.readLine())!=null) {
            String[] palabra=cadena.split(" ");
            System.out.println(cadena);
            cifrar(palabra,e,n,wr);
        }
        
        b.close();
        wr.close();
        bw.close();
        
    }
    
    
    
    
    public static void leerarchivodescif(String archivo, BigInteger d,BigInteger n) throws FileNotFoundException, IOException{
        String cadena;
        int i=0;
        
        String ruta="";
        for(int l=0;l<archivo.length();l++){
            if(archivo.charAt(l)!='.'){
                ruta= ruta+archivo.charAt(l);
            }else{
                break;
            }
        }
        
        File k= new File(ruta+" descifrado.txt");
        FileWriter w = new FileWriter(k);
        BufferedWriter bw = new BufferedWriter(w);
        PrintWriter wr = new PrintWriter(bw);
        
        FileReader f = new FileReader(archivo);
        BufferedReader b = new BufferedReader(f);
        
        while((cadena = b.readLine())!=null) {
            int x=0;
            String[] palabra=cadena.split(" ");
            System.out.println(cadena);
            while(true){
                String[] letrra=palabra[x].split("/");
                descifrar(letrra,d,n,wr);
                x++;
                if(x==palabra.length){
                    break;
                }
            }
            
        }
        
        b.close();
        wr.close();
        bw.close();
        
    }
       
}


